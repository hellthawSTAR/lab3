namespace HotelBooking;

public static class Program
{
    [STAThread]
    public static void Main()
    {
        ApplicationConfiguration.Initialize();
        Application.Run(new MainForm());
    }
}

public class MainForm : Form
{
    private static readonly Color Accent = Color.FromArgb(59, 111, 224);
    private static readonly Color Dark = Color.FromArgb(31, 42, 68);
    private static readonly Color Muted = Color.FromArgb(105, 115, 135);
    private static readonly Color Surface = Color.FromArgb(243, 245, 249);

    private static readonly string[] TypeNames = { "Стандарт", "Делюкс", "Люкс", "Семейный" };
    private static readonly string[] LoyaltyNames = { "Нет", "Серебряный", "Золотой", "Платиновый" };

    private readonly BookingService _service;
    private readonly List<IDiscountStrategy> _strategies = new()
    {
        new LongStayDiscountStrategy(),
        new LoyaltyDiscountStrategy()
    };

    private readonly DateTimePicker _dtpIn = new();
    private readonly DateTimePicker _dtpOut = new();
    private readonly ComboBox _cmbType = new();
    private readonly NumericUpDown _numMin = new();
    private readonly NumericUpDown _numMax = new();
    private readonly NumericUpDown _numGuests = new();
    private readonly Button _btnFind = new();
    private readonly DataGridView _gridRooms = new();

    private readonly TextBox _txtName = new();
    private readonly TextBox _txtEmail = new();
    private readonly TextBox _txtPhone = new();
    private readonly ComboBox _cmbLoyalty = new();
    private readonly ComboBox _cmbStrategy = new();
    private readonly Button _btnCalc = new();
    private readonly Button _btnBook = new();
    private readonly Label _lblPrice = new();

    private readonly DataGridView _gridBookings = new();
    private readonly TextBox _txtLog = new();

    public MainForm()
    {
        Text = "Система бронирования отелей";
        Font = new Font("Segoe UI", 10f);
        BackColor = Surface;
        ClientSize = new Size(1100, 780);
        MinimumSize = new Size(1100, 780);
        StartPosition = FormStartPosition.CenterScreen;

        _service = new BookingService(new PriceCalculator(_strategies[0]));

        var plan = new (RoomType Type, int Number)[]
        {
            (RoomType.Standard, 101), (RoomType.Standard, 102),
            (RoomType.Deluxe, 201), (RoomType.Deluxe, 202),
            (RoomType.Suite, 301),
            (RoomType.Family, 401), (RoomType.Family, 402)
        };
        foreach (var (type, number) in plan)
            _service.AddRoom(RoomFactory.Create(type, number));

        Action<string> log = text => _txtLog.AppendText(text + Environment.NewLine);
        _service.Attach(new EmailNotifier(log));
        _service.Attach(new SmsNotifier(log));

        BuildInterface();
        RunSearch();
    }

    private void BuildInterface()
    {
        var root = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 4,
            Padding = new Padding(15),
            BackColor = Surface
        };
        root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 105));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 50));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 135));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 50));

        root.Controls.Add(BuildSearchCard(), 0, 0);
        root.Controls.Add(BuildRoomsCard(), 0, 1);
        root.Controls.Add(BuildBookingCard(), 0, 2);
        root.Controls.Add(BuildBottomRow(), 0, 3);

        Controls.Add(root);
        Controls.Add(BuildHeader());
    }

    private static Panel BuildHeader()
    {
        var header = new Panel { Dock = DockStyle.Top, Height = 72, BackColor = Dark };
        header.Controls.Add(new Label
        {
            Text = "Система бронирования отелей",
            Left = 20,
            Top = 8,
            AutoSize = true,
            ForeColor = Color.White,
            Font = new Font("Segoe UI Semibold", 18f)
        });
        header.Controls.Add(new Label
        {
            Text = "Поиск номеров, расчёт стоимости и бронирование",
            Left = 22,
            Top = 44,
            AutoSize = true,
            ForeColor = Color.FromArgb(170, 182, 210),
            Font = new Font("Segoe UI", 9.5f)
        });
        return header;
    }

    private Panel BuildSearchCard()
    {
        var card = Card("Поиск доступных номеров");

        Caption(card, "Заезд", 15, 48);
        Put(card, _dtpIn, 70, 45, 115);
        Caption(card, "Выезд", 200, 48);
        Put(card, _dtpOut, 260, 45, 115);
        Caption(card, "Тип", 390, 48);
        Put(card, _cmbType, 430, 45, 110);
        Caption(card, "Цена от", 555, 48);
        Put(card, _numMin, 620, 45, 85);
        Caption(card, "до", 715, 48);
        Put(card, _numMax, 740, 45, 85);
        Caption(card, "Гостей", 840, 48);
        Put(card, _numGuests, 895, 45, 50);
        Put(card, _btnFind, 965, 43, 90);

        _dtpIn.Format = DateTimePickerFormat.Short;
        _dtpOut.Format = DateTimePickerFormat.Short;
        _dtpIn.MinDate = DateTime.Today;
        _dtpIn.Value = DateTime.Today.AddDays(1);
        _dtpOut.MinDate = DateTime.Today.AddDays(1);
        _dtpOut.Value = DateTime.Today.AddDays(3);
        _dtpIn.ValueChanged += (_, _) =>
        {
            var minOut = _dtpIn.Value.Date.AddDays(1);
            _dtpOut.MinDate = minOut;
            if (_dtpOut.Value.Date < minOut) _dtpOut.Value = minOut;
        };

        _cmbType.DropDownStyle = ComboBoxStyle.DropDownList;
        _cmbType.Items.Add("Любой");
        _cmbType.Items.AddRange(TypeNames);
        _cmbType.SelectedIndex = 0;

        foreach (var n in new[] { _numMin, _numMax })
        {
            n.Minimum = 0;
            n.Maximum = 100000;
            n.Increment = 500;
            n.ThousandsSeparator = true;
        }
        _numMax.Value = 100000;
        _numGuests.Minimum = 1;
        _numGuests.Maximum = 10;

        PrimaryButton(_btnFind, "Найти");
        _btnFind.Click += (_, _) => RunSearch();

        return card;
    }

    private Panel BuildRoomsCard()
    {
        var card = Card("Доступные номера", new Padding(10, 40, 10, 10));
        StyleGrid(_gridRooms);
        AddColumns(_gridRooms, "№", "Тип", "Цена за ночь", "Мест");
        card.Controls.Add(_gridRooms);
        return card;
    }

    private Panel BuildBookingCard()
    {
        var card = Card("Бронирование выбранного номера");

        Caption(card, "Гость", 15, 48);
        Put(card, _txtName, 70, 45, 180);
        Caption(card, "Email", 265, 48);
        Put(card, _txtEmail, 315, 45, 200);
        Caption(card, "Телефон", 530, 48);
        Put(card, _txtPhone, 600, 45, 150);
        Caption(card, "Лояльность", 765, 48);
        Put(card, _cmbLoyalty, 860, 45, 130);

        Caption(card, "Скидка", 15, 90);
        Put(card, _cmbStrategy, 70, 87, 240);
        Put(card, _btnCalc, 325, 85, 120);
        Put(card, _btnBook, 455, 85, 130);
        Put(card, _lblPrice, 605, 80, 450);

        _cmbLoyalty.DropDownStyle = ComboBoxStyle.DropDownList;
        _cmbLoyalty.Items.AddRange(LoyaltyNames);
        _cmbLoyalty.SelectedIndex = 0;

        _cmbStrategy.DropDownStyle = ComboBoxStyle.DropDownList;
        _cmbStrategy.Items.AddRange(_strategies.Select(s => s.Name).ToArray());
        _cmbStrategy.SelectedIndex = 0;
        _cmbStrategy.SelectedIndexChanged += (_, _) =>
            _service.Calculator.Strategy = _strategies[_cmbStrategy.SelectedIndex];

        SecondaryButton(_btnCalc, "Рассчитать");
        _btnCalc.Click += (_, _) => CalculatePrice();

        PrimaryButton(_btnBook, "Забронировать");
        _btnBook.Click += (_, _) => Book();

        _lblPrice.AutoSize = false;
        _lblPrice.Height = 46;
        _lblPrice.ForeColor = Dark;
        _lblPrice.Font = new Font("Segoe UI Semibold", 10f);
        _lblPrice.Text = "Выберите номер в таблице и нажмите «Рассчитать».";

        return card;
    }

    private TableLayoutPanel BuildBottomRow()
    {
        var row = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
            RowCount = 1,
            BackColor = Surface
        };
        row.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 58));
        row.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 42));

        var bookingsCard = Card("Бронирования", new Padding(10, 40, 10, 10));
        bookingsCard.Margin = new Padding(0, 0, 10, 0);
        StyleGrid(_gridBookings);
        AddColumns(_gridBookings, "№", "Гость", "Номер", "Заезд", "Выезд", "Итого");
        bookingsCard.Controls.Add(_gridBookings);

        var logCard = Card("Уведомления", new Padding(15, 40, 15, 10));
        logCard.Margin = new Padding(0);
        _txtLog.Dock = DockStyle.Fill;
        _txtLog.Multiline = true;
        _txtLog.ReadOnly = true;
        _txtLog.BorderStyle = BorderStyle.None;
        _txtLog.BackColor = Color.White;
        _txtLog.ForeColor = Dark;
        _txtLog.ScrollBars = ScrollBars.Vertical;
        _txtLog.Font = new Font("Segoe UI", 9.5f);
        logCard.Controls.Add(_txtLog);

        row.Controls.Add(bookingsCard, 0, 0);
        row.Controls.Add(logCard, 1, 0);
        return row;
    }

    private DateOnly CheckIn() => DateOnly.FromDateTime(_dtpIn.Value);

    private DateOnly CheckOut() => DateOnly.FromDateTime(_dtpOut.Value);

    private void RunSearch()
    {
        try
        {
            var criteria = new RoomSearchCriteria(CheckIn(), CheckOut())
            {
                Type = _cmbType.SelectedIndex > 0 ? (RoomType)(_cmbType.SelectedIndex - 1) : null,
                MinPrice = _numMin.Value,
                MaxPrice = _numMax.Value,
                Guests = (int)_numGuests.Value
            };

            _gridRooms.Rows.Clear();
            foreach (var r in _service.Search(criteria))
            {
                int i = _gridRooms.Rows.Add(r.Number, TypeNames[(int)r.Type], $"{r.PricePerNight:N0} ₽", r.Capacity);
                _gridRooms.Rows[i].Tag = r;
            }
        }
        catch (InvalidOperationException ex)
        {
            Warn(ex.Message);
        }
    }

    private Room? SelectedRoom()
    {
        if (_gridRooms.SelectedRows.Count == 0)
        {
            Warn("Сначала выберите номер в таблице.");
            return null;
        }
        return _gridRooms.SelectedRows[0].Tag as Room;
    }

    private Guest? ReadGuest()
    {
        if (string.IsNullOrWhiteSpace(_txtName.Text) ||
            string.IsNullOrWhiteSpace(_txtEmail.Text) ||
            string.IsNullOrWhiteSpace(_txtPhone.Text))
        {
            Warn("Заполните имя, email и телефон гостя.");
            return null;
        }
        return new Guest(_txtName.Text.Trim(), _txtEmail.Text.Trim(), _txtPhone.Text.Trim(),
                         (LoyaltyLevel)_cmbLoyalty.SelectedIndex);
    }

    private void CalculatePrice()
    {
        var room = SelectedRoom();
        var guest = ReadGuest();
        if (room is null || guest is null) return;

        try
        {
            var price = _service.CalculatePrice(room, guest, CheckIn(), CheckOut());
            _lblPrice.Text =
                $"Без скидки: {price.BasePrice:N0} ₽, скидка: {price.DiscountPercent}%{Environment.NewLine}" +
                $"Итого: {price.Total:N0} ₽";
        }
        catch (InvalidOperationException ex)
        {
            Warn(ex.Message);
        }
    }

    private void Book()
    {
        var room = SelectedRoom();
        var guest = ReadGuest();
        if (room is null || guest is null) return;

        try
        {
            var booking = _service.CreateBooking(guest, room, CheckIn(), CheckOut());
            _gridBookings.Rows.Add(booking.Id, guest.Name, room.Number,
                                   booking.CheckIn.ToString("dd.MM.yyyy"),
                                   booking.CheckOut.ToString("dd.MM.yyyy"),
                                   $"{booking.Price.Total:N0} ₽");
            _lblPrice.Text = $"Бронь #{booking.Id} создана.{Environment.NewLine}Итого: {booking.Price.Total:N0} ₽";
            RunSearch();
        }
        catch (InvalidOperationException ex)
        {
            Warn(ex.Message);
        }
    }

    private static void Warn(string message) =>
        MessageBox.Show(message, "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);

    private static Panel Card(string title, Padding? padding = null)
    {
        var card = new Panel
        {
            Dock = DockStyle.Fill,
            BackColor = Color.White,
            Margin = new Padding(0, 0, 0, 10),
            Padding = padding ?? Padding.Empty
        };
        card.Controls.Add(new Label
        {
            Text = title,
            Left = 15,
            Top = 10,
            AutoSize = true,
            ForeColor = Dark,
            Font = new Font("Segoe UI Semibold", 11f)
        });
        return card;
    }

    private static void Caption(Control parent, string text, int x, int y) =>
        parent.Controls.Add(new Label { Text = text, Left = x, Top = y, AutoSize = true, ForeColor = Muted });

    private static void Put(Control parent, Control control, int x, int y, int width)
    {
        control.Left = x;
        control.Top = y;
        control.Width = width;
        parent.Controls.Add(control);
    }

    private static void PrimaryButton(Button button, string text)
    {
        button.Text = text;
        button.Height = 32;
        button.FlatStyle = FlatStyle.Flat;
        button.FlatAppearance.BorderSize = 0;
        button.BackColor = Accent;
        button.ForeColor = Color.White;
        button.Cursor = Cursors.Hand;
    }

    private static void SecondaryButton(Button button, string text)
    {
        button.Text = text;
        button.Height = 32;
        button.FlatStyle = FlatStyle.Flat;
        button.FlatAppearance.BorderColor = Accent;
        button.FlatAppearance.BorderSize = 1;
        button.BackColor = Color.White;
        button.ForeColor = Accent;
        button.Cursor = Cursors.Hand;
    }

    private static void AddColumns(DataGridView grid, params string[] titles)
    {
        foreach (var title in titles)
            grid.Columns.Add(title, title);
    }

    private static void StyleGrid(DataGridView grid)
    {
        var headerColor = Color.FromArgb(238, 241, 248);

        grid.Dock = DockStyle.Fill;
        grid.AllowUserToAddRows = false;
        grid.AllowUserToDeleteRows = false;
        grid.AllowUserToResizeRows = false;
        grid.ReadOnly = true;
        grid.MultiSelect = false;
        grid.RowHeadersVisible = false;
        grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        grid.BackgroundColor = Color.White;
        grid.BorderStyle = BorderStyle.None;
        grid.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
        grid.GridColor = Color.FromArgb(230, 233, 240);
        grid.EnableHeadersVisualStyles = false;
        grid.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
        grid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
        grid.ColumnHeadersHeight = 34;
        grid.ColumnHeadersDefaultCellStyle.BackColor = headerColor;
        grid.ColumnHeadersDefaultCellStyle.SelectionBackColor = headerColor;
        grid.ColumnHeadersDefaultCellStyle.ForeColor = Dark;
        grid.ColumnHeadersDefaultCellStyle.SelectionForeColor = Dark;
        grid.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI Semibold", 9.5f);
        grid.DefaultCellStyle.ForeColor = Dark;
        grid.DefaultCellStyle.SelectionBackColor = Color.FromArgb(220, 230, 251);
        grid.DefaultCellStyle.SelectionForeColor = Dark;
        grid.DefaultCellStyle.Padding = new Padding(4, 0, 4, 0);
        grid.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(250, 251, 253);
        grid.RowTemplate.Height = 30;
    }
}
