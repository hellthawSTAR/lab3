namespace HotelBooking;

public enum RoomType { Standard, Deluxe, Suite, Family }

public enum LoyaltyLevel { None, Silver, Gold, Platinum }

public abstract class Room
{
    protected Room(int number) => Number = number;

    public int Number { get; }
    public abstract RoomType Type { get; }
    public abstract decimal PricePerNight { get; }
    public abstract int Capacity { get; }
}

public sealed class StandardRoom : Room
{
    public StandardRoom(int number) : base(number) { }
    public override RoomType Type => RoomType.Standard;
    public override decimal PricePerNight => 3000m;
    public override int Capacity => 2;
}

public sealed class DeluxeRoom : Room
{
    public DeluxeRoom(int number) : base(number) { }
    public override RoomType Type => RoomType.Deluxe;
    public override decimal PricePerNight => 5500m;
    public override int Capacity => 3;
}

public sealed class SuiteRoom : Room
{
    public SuiteRoom(int number) : base(number) { }
    public override RoomType Type => RoomType.Suite;
    public override decimal PricePerNight => 10000m;
    public override int Capacity => 4;
}

public sealed class FamilyRoom : Room
{
    public FamilyRoom(int number) : base(number) { }
    public override RoomType Type => RoomType.Family;
    public override decimal PricePerNight => 7000m;
    public override int Capacity => 5;
}

public static class RoomFactory
{
    public static Room Create(RoomType type, int number) => type switch
    {
        RoomType.Standard => new StandardRoom(number),
        RoomType.Deluxe => new DeluxeRoom(number),
        RoomType.Suite => new SuiteRoom(number),
        RoomType.Family => new FamilyRoom(number),
        _ => throw new ArgumentOutOfRangeException(nameof(type))
    };
}

public class Guest
{
    public Guest(string name, string email, string phone, LoyaltyLevel loyalty)
    {
        Name = name;
        Email = email;
        Phone = phone;
        Loyalty = loyalty;
    }

    public string Name { get; }
    public string Email { get; }
    public string Phone { get; }
    public LoyaltyLevel Loyalty { get; }
}

public record PriceResult(decimal BasePrice, decimal DiscountPercent, decimal Total);

public class Booking
{
    public Booking(int id, Guest guest, Room room, DateOnly checkIn, DateOnly checkOut, PriceResult price)
    {
        Id = id;
        Guest = guest;
        Room = room;
        CheckIn = checkIn;
        CheckOut = checkOut;
        Price = price;
    }

    public int Id { get; }
    public Guest Guest { get; }
    public Room Room { get; }
    public DateOnly CheckIn { get; }
    public DateOnly CheckOut { get; }
    public PriceResult Price { get; }
}

public interface IDiscountStrategy
{
    string Name { get; }
    decimal GetDiscountPercent(Guest guest, int nights);
}

public class LongStayDiscountStrategy : IDiscountStrategy
{
    public string Name => "За длительное проживание";

    public decimal GetDiscountPercent(Guest guest, int nights) => nights switch
    {
        >= 14 => 15m,
        >= 7 => 10m,
        >= 3 => 5m,
        _ => 0m
    };
}

public class LoyaltyDiscountStrategy : IDiscountStrategy
{
    public string Name => "По программе лояльности";

    public decimal GetDiscountPercent(Guest guest, int nights) => guest.Loyalty switch
    {
        LoyaltyLevel.Silver => 3m,
        LoyaltyLevel.Gold => 7m,
        LoyaltyLevel.Platinum => 12m,
        _ => 0m
    };
}

public class PriceCalculator
{
    public PriceCalculator(IDiscountStrategy strategy) => Strategy = strategy;

    public IDiscountStrategy Strategy { get; set; }

    public PriceResult Calculate(Room room, Guest guest, int nights)
    {
        decimal basePrice = room.PricePerNight * nights;
        decimal percent = Strategy.GetDiscountPercent(guest, nights);
        decimal total = basePrice - Math.Round(basePrice * percent / 100m, 0);
        return new PriceResult(basePrice, percent, total);
    }
}

public interface IBookingObserver
{
    void Update(Booking booking);
}

public interface IBookingSubject
{
    void Attach(IBookingObserver observer);
    void Detach(IBookingObserver observer);
    void Notify(Booking booking);
}

public class EmailNotifier : IBookingObserver
{
    private readonly Action<string> _output;

    public EmailNotifier(Action<string> output) => _output = output;

    public void Update(Booking b) =>
        _output($"[Email → {b.Guest.Email}] Бронь #{b.Id} подтверждена: номер {b.Room.Number}, " +
                $"{b.CheckIn:dd.MM.yyyy} – {b.CheckOut:dd.MM.yyyy}, сумма {b.Price.Total:N0} ₽");
}

public class SmsNotifier : IBookingObserver
{
    private readonly Action<string> _output;

    public SmsNotifier(Action<string> output) => _output = output;

    public void Update(Booking b) =>
        _output($"[SMS → {b.Guest.Phone}] Бронь #{b.Id} подтверждена. Заезд {b.CheckIn:dd.MM}.");
}

public class RoomSearchCriteria
{
    public RoomSearchCriteria(DateOnly checkIn, DateOnly checkOut)
    {
        CheckIn = checkIn;
        CheckOut = checkOut;
    }

    public DateOnly CheckIn { get; }
    public DateOnly CheckOut { get; }
    public RoomType? Type { get; init; }
    public decimal? MinPrice { get; init; }
    public decimal? MaxPrice { get; init; }
    public int? Guests { get; init; }

    public bool Matches(Room room) =>
        (Type is null || room.Type == Type) &&
        (MinPrice is null || room.PricePerNight >= MinPrice) &&
        (MaxPrice is null || room.PricePerNight <= MaxPrice) &&
        (Guests is null || room.Capacity >= Guests);
}

public class BookingService : IBookingSubject
{
    private readonly List<Room> _rooms = new();
    private readonly List<Booking> _bookings = new();
    private readonly List<IBookingObserver> _observers = new();
    private int _nextId = 1;

    public BookingService(PriceCalculator calculator) => Calculator = calculator;

    public PriceCalculator Calculator { get; }
    public IReadOnlyList<Booking> Bookings => _bookings;

    public void AddRoom(Room room) => _rooms.Add(room);

    public void Attach(IBookingObserver observer) => _observers.Add(observer);

    public void Detach(IBookingObserver observer) => _observers.Remove(observer);

    public void Notify(Booking booking)
    {
        foreach (var observer in _observers.ToList())
            observer.Update(booking);
    }

    public bool IsAvailable(Room room, DateOnly checkIn, DateOnly checkOut) =>
        !_bookings.Any(b => b.Room.Number == room.Number &&
                            checkIn < b.CheckOut && checkOut > b.CheckIn);

    public List<Room> Search(RoomSearchCriteria criteria)
    {
        CheckDates(criteria.CheckIn, criteria.CheckOut);
        return _rooms
            .Where(criteria.Matches)
            .Where(r => IsAvailable(r, criteria.CheckIn, criteria.CheckOut))
            .OrderBy(r => r.PricePerNight)
            .ToList();
    }

    public PriceResult CalculatePrice(Room room, Guest guest, DateOnly checkIn, DateOnly checkOut)
    {
        CheckDates(checkIn, checkOut);
        return Calculator.Calculate(room, guest, checkOut.DayNumber - checkIn.DayNumber);
    }

    public Booking CreateBooking(Guest guest, Room room, DateOnly checkIn, DateOnly checkOut)
    {
        var price = CalculatePrice(room, guest, checkIn, checkOut);

        if (!IsAvailable(room, checkIn, checkOut))
            throw new InvalidOperationException($"Номер {room.Number} занят на выбранные даты.");

        var booking = new Booking(_nextId++, guest, room, checkIn, checkOut, price);
        _bookings.Add(booking);
        Notify(booking);
        return booking;
    }

    private static void CheckDates(DateOnly checkIn, DateOnly checkOut)
    {
        if (checkOut <= checkIn)
            throw new InvalidOperationException("Дата выезда должна быть позже даты заезда.");
    }
}
